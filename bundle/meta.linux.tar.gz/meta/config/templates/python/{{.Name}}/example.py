class Example(object):
    def run(self):
        return 1
