package main_test

import "testing"

func TestExample(t *testing.T) {
	if false {
		t.Fail()
	}
}
